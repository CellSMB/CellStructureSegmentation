This is our First version of Cell Segmenter
